Collin Braeuning - cbraeun 
SDE2m- OCAML CYK Parse Tables

Pledge:
On my honor I have neither given nor received aid on this
exam. -Collin Braeuning

sde2.caml
Provides the functions used to manipulate and build a CYK parse table's first row.
Each function implemented has been described in SDE2 requirements document.
They all have inputs and outputs defined, as well as their expected signatures.
To ensure proper function all of these signatures must be correct

sde2.log
Contains test output from sde2.caml.
This file shows at least 2 uses of each function defined in the SDE2 requirement document.
Each of the functions has correct output.